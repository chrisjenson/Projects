Project 2 Report
Yash Dhayal, Chris Jenson, and Gregory Yezhov

Task: Implement language model techniques such as training, probability estimation, model evaluation, smoothing, and using an LM. Experience was gained in corpus selection and the impact a corpus has on the learned models. All corpora for this assignment are in English.

Using the program (T1 - T4)
- Open the terminal
- Navigate to the location where the CJ_YD_GY_Prj2.tar.gz file was downloaded
  	-     Ex. if downloaded to Downloads, enter "cd Downloads"
- To extract the CJ_YD_GY_Prj2.tar.gz file, type "tar -zxvf CJ_YD_GY_Prj2.tar.gz". 
- Type "cd Project2" to get into the extracted folder named Project2 containing the python code
    NOTE: To run the following scripts, make sure you have python3 installed. Enter "sudo apt-get install python3.6" to install it.
- Type "ProjectCode.py", and hit enter
- You will be then prompted to enter a training file of your choosing, acceptable inputs are
“training.txt” or “training2.txt” 
“training.txt” contains the corpus of Stanford sentences
“training2.txt” contains the corpus of economic report statements
- You will be then prompted to enter a test file
- Type "test.txt", and hit enter
- You will be prompted to enter a word for unigram calculation, type your word then press enter
- You will be prompted to enter the first word for the bigram calculation, type your word then press enter
- You will be prompted to enter the second word for the bigram calculation, type your word then press enter
- The program will print the unsmoothed unigram and bigram results based on the training data and test data. 
- It will ask if you want to calculate the smoothed probabilities. Enter either “yes” or “no” to do the calculation or not respectively
- It will ask if you want to calculate the perplexity. Enter either “yes” or “no” to do the calculation or not respectively
- It will ask if you want to generate sentences. Enter either “yes” or “no” to do the generation or not respectively
- It will ask if you want to generate the top ten unsmoothed and smoothed uni/bigrams. Enter either “yes” or “no” to do the generation or not respectively. Note that this will take some time


T5: Corpora
The corpora chosen for testing were a subset of Stanford's sentence collection and a collection of economical reports. 

These were chosen for several reasons, the first being that they are small in comparison to many other corpora which made testing faster and easier for the group. The second reason was because of the test data. The test data contains descriptions, mainly geography/location descriptions, so we thought that the more causal vs more formal corpora would be interesting. The third reason is that both came mostly preprocessed. This meant that our code had to do very little preprocessing itself. To expand this project to be more accepting and versatile, increasing the range of acceptable input corpora would be a priority. A rough preprocessing function was included but not used to its full extent.


T5: Top 10 Unsmoothed Unigrams & Bigrams with Probabilities
When analyzing our top 10 unsmoothed Unigram probabilities, the majority of the words (7/10) that were found to be in the top ten were among the most common words in the English lexicon. For both training sets, our machine correctly evaluated the frequency of the beginning and ending sentence markers, which is not only what was desired, but also helps to show that our Unigram probability calculator is taking the correct factors into account when computing the training probabilities.

In the first training set, the words “the”,”of”, “and”, “a”, “in”, “to”, and “is” are all either prepositions or articles, which are the most commonly used types of vocabulary terms used when communicating in English. However, one of these words - “num” - is not what one would consider a ‘common’ word yet appears surprisingly often: so much so that it is the 9th most used word in the vocabulary.  “Num” is also interesting because it only occurs in one of the smoothed bigram probabilities despite being so common. Yet, when reviewing the unsmoothed Bigram probabilities, “num” doesn’t show up at all in the generated top 10.  

In another vein, the outputs for our unsmoothed Bigram probabilities do not contain commonly-used word phrases, instead only evaluating the bigram probabilities of the first ten words in the vocabulary. You can see this by considering how the first element in each pair alphabetically follows the preceding pair, and considering that we are looking for the top 10 most probable pairs rather than the first (“top”) 10 elements in the vocabulary. This leads us to believe that there either exists an error in the Bigram probability calculations.

For our second training data set, many of the aforementioned behaviors of the first training set are observed, except for the unexpected inclusion of the two new words “chairman” and “board”. Both of which are relatively specific nouns, given the nature of the corpus we can expect an increase in their probability, but the increase is rather drastic.  It is possible the two words appear an exorbitant amount of times in our training2.txt data set, or the unigram probability calculator for the top ten unsmoothed unigrams incorrectly capitalizes on the frequency of these two specific words. 

T6: Unsmoothed Generated Sentences
The following is the error presented when generating unsmoothed sentences
- Unsmoothed -
Traceback (most recent call last):
  File "C:/Users/dhaya/PycharmProjects/Project2/LangModel.py", line 390, in <module>
    generate_sentence(sorted_vocab_keys, dataset_model_unsmoothed)
  File "C:/Users/dhaya/PycharmProjects/Project2/LangModel.py", line 305, in generate_sentence
    nextWord = find_weighted_next_word(sorted_vocab_keys, model, curWord)
  File "C:/Users/dhaya/PycharmProjects/Project2/LangModel.py", line 328, in find_weighted_next_word
    top_key = max(prob_dict, key=prob_dict.get)
ValueError: max() arg is an empty sequence


T7: Smoothed T5 & T6
From our top 10 smoothed unigrams and bigrams, there are some things to notice. Finding 'the' as the top unigram isn't surprising, but having the start sentence '<s>' and end sentence '</s>' symbols as the 2nd and 3rd highest as well as having the same probability is interesting. Having the same probability is due to those 2 occuring consistently every line. Another noticeable thing is that 'chairman' is 8th on the top 10 unigrams. It seems quite strange for a word like 'chairman' that is quite uncommon to have a higher unigram probability than “in”. In addition, the top 10 bigrams have strangely specific bigrams like “chairman, of” and “chief, executive” higher than seemingly common bigrams like “in, the” and “to, the”. The most likely reason for this is that training2.txt is that of economic reports where words like “chairman”, “chief”, and “executive” would be common, but it is still surprising to see how they can appear more often than common english language words.

T8: Perplexity
Perplexity is a measurement of how well a language model, in our case being the unigram and bigram, can predict a sample text. A lower perplexity value would equate that the model predicts its sample well. Furthermore, as the n-value of the n-gram increases (unigram, bigram, trigram, etc.), the perplexity value becomes lower. This means that higher degree n-grams are more accurate at predicting a sample text than lower degree n-grams.

The following is the perplexity result of our test.txt file:

PERPLEXITY of test.txt
unigram:  2093.0509302258565
bigram:  4267.261733404621

However, the bigram’s perplexity value should be lower than the unigram's perplexity value which indicates a calculation error.

Error and Deficiencies:
The smaller corpora chosen has led to a possible error in the perplexity calculation. The calculation results in the bigram performing worse than the unigram which is unexpected. The margin of error leads us to believe there may be an error in the calculation but it would require more extensive testing and evaluation to determine.

There are situations in which our unigram and bigram probabilities produce a blank output, and that is due to the corpora we've used being small in size. In situations of the bigram where the 2 words are never together, the unsmoothed and smoothed probability will have no value. Using larger corpora would be a more inclusive option for having all possible varieties of word choices for the unigram and bigram. 

Smoothed Sentences : training.txt
['<s>', 'greek', 'hebrew', 'middle', 'ages', 'dating', 'soon', 'ab', 'abaci', 'in', 'the', 'year', '</s>']
['<s>', 'included', 'interface', 'updates', 'a', 'few', 'exceptional', 'cases', 'not', 'only', 'be', 'granted', 'autonomy', 'through', 'the', 'num', '</s>']
['<s>', 'of', 'this', 'time', 'the', 'num', 'morissette', 'has', 'been', 'constituted', 'abacus', 'a', 'is', 'the', 'year', '</s>']
['<s>', 'lavigne', 'losing', 'your', 'love', 'and', 'is', 'also', 'a', 'way', 'to', 'a', 'few', 'dates', '</s>']
['<s>', 'in', 'which', 'a', 'is', 'not', 'only', 'to', 'the', 'first', 'single', 'digits', 'and', 'is', 'a', 'particular', 'work', 'of', 'the', 'album', '</s>']

Top Ten Unsmoothed Unigrams : training.txt
{'the': 0.07041091130223265, '<s>': 0.04343671270958214, '</s>': 0.04343671270958214, 'of': 0.03922335157675267, 'and': 0.028103553123099645, 'a': 0.025540787073234296, 'in': 0.025453913647815133, 'to': 0.02415081226652767, 'num': 0.017200938232994525, 'is': 0.014551298757710017}

Top Ten Unsmoothed Bigrams : training.txt
{'ab, </s>': 1.0, 'abaci, in': 1.0, 'abacus, to': 1.0, 'abandonment, of': 1.0, 'abbreviation, for': 1.0, 'abbreviations, resembling': 1.0, 'abilities, </s>': 1.0, 'abraham, wald': 1.0, 'absolutely, indispensable': 1.0, 'absurd, namely': 1.0}

Top Ten Smoothed Unigrams : training.txt
{'the': 0.05840835433921498, '<s>': 0.03604609290601368, '</s>': 0.03604609290601368, 'of': 0.0325531148721642, 'and': 0.023334533669427438, 'a': 0.021209938782859202, 'in': 0.02113791861721282, 'to': 0.020057616132517105, 'num': 0.014296002880806626, 'is': 0.012099387828592005}

Top Ten Smoothed Bigrams : training.txt
{'of, the': 0.04087048832271762, 'in, the': 0.027553889409559513, '<s>, the': 0.026265437467385633, '<s>, in': 0.017742216037571753, 'to, the': 0.01639962299717248, 'on, the': 0.012611879576891782, 'in, num': 0.011246485473289597, 'and, the': 0.010934025203854707, 'it, is': 0.009983700081499592, 'for, the': 0.009780439121756487}



Smoothed Sentences : training2.txt
['<s>', 'for', 'a', 'new', 'bid', 'that', 'the', 'company', '</s>']
['<s>', 'John', 'Amerman', '$', '4', 'billion', 'in', 'his', 'board', 'and', 'chief', 'executive', 'of', 'the', 'company', '</s>']
['<s>', '', '10', 'business', 'appears', 'to', 'a', 'new', 'SEC', 'authority', 'during', 'the', 'board', 'to', 'a', 'new', 'post', 'of', 'its', 'board', 'and', 'chief', 'executive', 'officer', '</s>']
['<s>', 'Trump', 'said', 'the', 'companys', 'board', 'to', 'sell', 'his', 'board', 'of', 'this', 'year', '</s>']
['<s>', 'a', 'particular', 'artistic', 'depictions', 'of', 'the', 'year', '</s>']

Top Ten Unsmoothed Unigrams : training2.txt
{'the': 0.05779107857807255, '<s>': 0.03926881546487645, '</s>': 0.03918793221984066, 'of': 0.037934241921785905, 'and': 0.027338536822097304, 'to': 0.026246613014114125, 'a': 0.023496582682897237, 'chairman': 0.021959801027217212, 'in': 0.014518542483924455, 'board': 0.0141141262587455}

Top Ten Unsmoothed Bigrams : training2.txt
{'1-for-10, reverse': 1.0, '10-member, board': 1.0, '10-month, suspended': 1.0, '1000, critics': 1.0, '105, a': 1.0, '109, million': 1.0, '10th, largest': 1.0, '11-member, board': 1.0, '12-member, board': 1.0, '12-point, limit': 1.0}

Top Ten Smoothed Unigrams : training2.txt
{'the': 0.04710144927536232, '<s>': 0.032015810276679844, '</s>': 0.03194993412384717, 'of': 0.03092885375494071, 'and': 0.02229907773386034, 'to': 0.021409749670619236, 'a': 0.0191699604743083, 'chairman': 0.017918313570487482, 'in': 0.011857707509881422, 'board': 0.01152832674571805}

Top Ten Smoothed Bigrams : training2.txt
{'of, the': 0.040474741326841146, 'chairman, of': 0.03658734013275053, 'chief, executive': 0.028331043956043956, 'and, chief': 0.02503961965134707, 'chairman, and': 0.022826614861583293, '<s>, The': 0.02165026495079485, 'executive, officer': 0.0197492701356689, 'the, board': 0.01939685685969135, 'in, the': 0.015518104455197732, 'to, the': 0.013846888429094381}
